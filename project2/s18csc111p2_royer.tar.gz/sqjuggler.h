/*
* Project 2: Stack & Queue ADT Juggler
* Programmer: Ian Royer
* Course: CSC111
* Professor: Dr. Lee
*/

#include "stackADT.h"
#include "queueADT.h"
#include <stdio.h>

void print_queue(Queue q);
void print_stack(Stack s);
